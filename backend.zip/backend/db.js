require("dotenv").config();
const mysql = require("mysql2");

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  timezone: "+08:00",
  dateStrings: true
});


// ================= DATABASE CONNECTION =================
db.connect((err) => {
  if (err) {
    console.error("❌ MySQL connection error:", err.message);
    return;
  }
  console.log("✅ MySQL connected to Hostinger database");
});

// ================= PROMISE WRAPPER =================
// Allows async/await usage
const dbPromise = db.promise();

module.exports = {
  db,
  dbPromise
};
