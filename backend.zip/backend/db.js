const mysql = require("mysql2");

// ================= HOSTINGER DATABASE CONFIG =================
// Replace these values with the details from your Hostinger hPanel
const db = mysql.createConnection({
  host: "localhost", 
  // Usually "localhost" on Hostinger
  // Sometimes: "mysql.hostinger.com"

  user: "u478425112_IT_ADMIN",
  // Example: "truck_user"

  password: "ArrowgoITAdmin123",
  // Example: "yourpassword"

  database: "u478425112_dbtruck",
  // Example: "dbtruck"

  timezone: "+08:00", // PH timezone
  dateStrings: true   // Prevent timezone shifting for DATE/DATETIME
});

// ================= DATABASE CONNECTION =================
db.connect((err) => {
  if (err) {
    console.error("❌ MySQL connection error:", err.message);
    return;
  }
  console.log("✅ MySQL connected to Hostinger database");
});

// ================= PROMISE WRAPPER =================
// Allows async/await usage
const dbPromise = db.promise();

module.exports = {
  db,
  dbPromise
};
