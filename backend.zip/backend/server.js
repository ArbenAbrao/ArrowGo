const express = require("express");
const cors = require("cors");
const app = express();   // ✅ MOVE THIS HERE
const PORT = process.env.PORT || 5000;

const { db } = require("./db");

// Route files
const trucksRoutes = require("./routes/trucks");
const typesRoutes = require("./routes/types");
const visitorRoutes = require("./routes/visitors");
const requestRoutes = require("./routes/requests"); 
const truckRequestRoutes = require("./routes/truckrequest");
const appointmentRequestRoutes = require("./routes/appointmentRequests");
const requestStatsRoutes = require("./routes/requestStats");
const requestAnalyticsRoutes = require("./routes/requestAnalytics");
const accountsRoutes = require("./routes/accounts");
const branchesRoutes = require("./routes/branches");

// ================= TEST DB ROUTE =================
app.get("/test-db", (req, res) => {
  db.query("SELECT 1", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: "Database is working ✅" });
  });
});

// ================= MIDDLEWARE =================
app.set("trust proxy", true);

app.use(cors({
  origin: [
    "https://tmvasarrowgo.vercel.app",
    "http://localhost:3000"
  ],
  credentials: true
}));

app.use(express.json());
app.use("/uploads", express.static("uploads"));

// ================= ROUTES =================
app.use("/api", trucksRoutes);
app.use("/api/truck-types", typesRoutes);
app.use("/api/visitors", visitorRoutes);
app.use("/api/requests", requestRoutes);
app.use("/api", truckRequestRoutes);
app.use("/api/appointment-requests", appointmentRequestRoutes);
app.use("/api/request-stats", requestStatsRoutes);
app.use("/api/requests", requestAnalyticsRoutes);
app.use("/api", accountsRoutes);
app.use("/api", branchesRoutes);

// ================= ROOT ROUTE =================
app.get("/", (req, res) => {
  res.status(200).send("🚚 Truck Management API is running! TRY 123");
});

// ================= START SERVER =================
app.listen(PORT, "0.0.0.0", () => {
  console.log("======================================");
  console.log("✅ Server successfully started");
  console.log(`👉 Local:   http://localhost:${PORT}`);
  console.log("======================================");
});
