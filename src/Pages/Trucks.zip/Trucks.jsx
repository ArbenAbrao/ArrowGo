// Trucks.jsx
import React, { useEffect, useMemo, useState, Fragment } from "react";
import { Dialog, Transition } from "@headlessui/react";

/**
 * Trucks.jsx
 * - Card layout (Style C) with green-themed accents (white card + green highlights)
 * - Date picker filter, Status (ALL/IN/OUT), Free-text search (type/driver/plate)
 * - Search history saved to localStorage
 * - Add / Edit modals, Time In / Time Out (badges + Set buttons)
 * - Local persistence for trucks + search history
 *
 * Header image (uploaded): /mnt/data/e6bc5a11-0335-49c5-9867-9eb2c0d13fed.png
 */

const STORAGE_KEYS = {
  TRUCKS: "trucks_v1",
  SEARCH_HISTORY: "truck_search_history_v1",
};

const headerImage = "/mnt/data/e6bc5a11-0335-49c5-9867-9eb2c0d13fed.png";

export default function Trucks() {
  const todayISO = new Date().toISOString().split("T")[0];

  // Trucks and persistence
  const [trucks, setTrucks] = useState([]);
useEffect(() => {
  fetch("http://localhost/trucks_api/getTrucks.php")
    .then(res => res.json())
    .then(data => setTrucks(data))
    .catch(err => console.error(err));
}, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TRUCKS, JSON.stringify(trucks));
    } catch (e) {
      console.warn("Save trucks failed", e);
    }
  }, [trucks]);

  // UI state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [currentTruck, setCurrentTruck] = useState(null);

  // Filters / Search
  const [filterDate, setFilterDate] = useState(todayISO);
  const [filterStatus, setFilterStatus] = useState("ALL"); // ALL / IN / OUT
  const [searchText, setSearchText] = useState("");

  // New truck form
  const [newTruck, setNewTruck] = useState({
    type: "",
    driver: "",
    plate: "",
    bay: "",
    date: todayISO,
    purpose: "",
    timeIn: "",
    timeOut: "",
  });

  // Search history (persisted)
  const [searchHistory, setSearchHistory] = useState([]);
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SEARCH_HISTORY);
      if (raw) setSearchHistory(JSON.parse(raw));
    } catch (e) {
      console.warn("Load search history failed", e);
    }
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SEARCH_HISTORY, JSON.stringify(searchHistory));
    } catch (e) {
      console.warn("Save search history failed", e);
    }
  }, [searchHistory]);

  // Helpers
  const fmtNow = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const nextId = () => (trucks.length ? Math.max(...trucks.map((t) => t.id || 0)) + 1 : 1);

  // Add truck
  const handleAddTruck = (e) => {
    e && e.preventDefault();
    const id = nextId();
    setTrucks((s) => [{ id, ...newTruck }, ...s]);
    setNewTruck({ type: "", driver: "", plate: "", bay: "", date: todayISO, purpose: "", timeIn: "", timeOut: "" });
    setIsAddOpen(false);
  };

  // Edit truck
  const handleOpenEdit = (truck) => {
    setCurrentTruck({ ...truck });
    setIsEditOpen(true);
  };
  const handleSaveEdit = (e) => {
    e && e.preventDefault();
    if (!currentTruck) return;
    setTrucks((s) => s.map((t) => (t.id === currentTruck.id ? { ...currentTruck } : t)));
    setIsEditOpen(false);
  };
  const handleDeleteTruck = (id) => {
    if (!window.confirm("Delete this truck?")) return;
    setTrucks((s) => s.filter((t) => t.id !== id));
    setIsEditOpen(false);
  };

  // Time in/out setters
  const handleSetTimeIn = (truckId) => {
    const time = fmtNow();
    setTrucks((s) => s.map((t) => (t.id === truckId ? { ...t, timeIn: time } : t)));
    if (currentTruck?.id === truckId) setCurrentTruck((c) => ({ ...c, timeIn: time }));
  };
  const handleSetTimeOut = (truckId) => {
    const time = fmtNow();
    setTrucks((s) => s.map((t) => (t.id === truckId ? { ...t, timeOut: time } : t)));
    if (currentTruck?.id === truckId) setCurrentTruck((c) => ({ ...c, timeOut: time }));
  };

  // Filtering
  const filteredTrucks = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    return trucks.filter((t) => {
      if (filterDate && t.date !== filterDate) return false;
      if (filterStatus === "IN" && !t.timeIn) return false;
      if (filterStatus === "OUT" && !t.timeOut) return false;
      if (!q) return true;
      const hay = `${t.type || ""} ${t.driver || ""} ${t.plate || ""}`.toLowerCase();
      return hay.includes(q);
    });
  }, [trucks, filterDate, filterStatus, searchText]);

  // Search history ops
  const saveCurrentSearch = () => {
    const entry = {
      id: Date.now(),
      name: `${filterDate} • ${filterStatus} • ${searchText || "-"}`,
      filters: { filterDate, filterStatus, searchText },
      createdAt: new Date().toISOString(),
    };
    setSearchHistory((s) => [entry, ...s].slice(0, 12));
  };
  const applyHistoryEntry = (entry) => {
    if (!entry?.filters) return;
    setFilterDate(entry.filters.filterDate || todayISO);
    setFilterStatus(entry.filters.filterStatus || "ALL");
    setSearchText(entry.filters.searchText || "");
  };
  const clearSearchHistory = () => {
    if (!window.confirm("Clear search history?")) return;
    setSearchHistory([]);
  };
  const removeHistoryItem = (id) => setSearchHistory((s) => s.filter((h) => h.id !== id));

  const statusBadge = (truck) => {
    if (truck.timeOut) return <span className="inline-block text-xs font-semibold px-2 py-1 rounded bg-red-100 text-red-700">OUT</span>;
    if (truck.timeIn) return <span className="inline-block text-xs font-semibold px-2 py-1 rounded bg-green-100 text-green-700">IN</span>;
    return null;
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6 text-black">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <img src={headerImage} alt="logo" className="w-14 h-14 rounded-md object-cover shadow-sm" />
            <div>
              <h1 className="text-3xl font-bold text-green-700">Truck List</h1>
              <p className="text-sm text-gray-500">Manage trucks — clock in/out, edit and search</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => setIsAddOpen(true)} className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
              + Add Truck
            </button>
          </div>
        </div>

        {/* Filters bar */}
        <div className="bg-white shadow rounded-lg p-4 mb-6 border-t-4 border-green-600">
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm text-gray-600 mb-1">Date</label>
              <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} className="border rounded px-3 py-2 w-full" />
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-1">Status</label>
              <div className="flex gap-2">
                {["ALL", "IN", "OUT"].map((s) => (
                  <button key={s} onClick={() => setFilterStatus(s)} className={`px-3 py-2 rounded ${filterStatus === s ? "bg-green-600 text-white" : "bg-white border text-gray-700"}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-1">Search (type / driver / plate)</label>
              <div className="flex gap-2">
                <input type="text" placeholder="Search..." value={searchText} onChange={(e) => setSearchText(e.target.value)} className="flex-1 border rounded px-3 py-2" />
                <button onClick={saveCurrentSearch} className="px-3 py-2 rounded bg-blue-600 text-white">Save</button>
                <HistoryDropdown history={searchHistory} onApply={applyHistoryEntry} onClear={clearSearchHistory} onRemove={removeHistoryItem} />
              </div>
            </div>
          </div>
        </div>

        {/* Card list (modern, spacious) */}
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTrucks.length === 0 ? (
            <div className="bg-white border rounded-lg p-6 text-center text-gray-500">No trucks found for the selected filters.</div>
          ) : (
            filteredTrucks.map((truck) => (
              <div key={truck.id} className="bg-white border rounded-lg shadow-sm p-4 flex items-start justify-between gap-4">
                {/* Left: main info */}
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800">{truck.type || "—"}</h3>
                      <p className="text-sm text-gray-500">Driver: <span className="text-gray-700 font-medium">{truck.driver || "—"}</span></p>
                      <p className="text-sm text-gray-500">Plate: <span className="text-gray-700 font-medium">{truck.plate || "—"}</span></p>
                      <p className="text-sm text-gray-500">Client: <span className="text-gray-700 font-medium">{truck.clientName || "—"}</span></p>

                    </div>

                    <div className="text-right">
                      <p className="text-sm text-gray-500 mb-1">Date</p>
                      <p className="font-medium text-gray-800">{truck.date}</p>
                      <div className="mt-2">{statusBadge(truck)}</div>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center gap-6 text-sm text-gray-600">
                    <div>
                      <span className="block text-xs text-gray-400">Time In</span>
                      <span className="font-medium">{truck.timeIn || "—"}</span>
                    </div>
                    <div>
                      <span className="block text-xs text-gray-400">Time Out</span>
                      <span className="font-medium">{truck.timeOut || "—"}</span>
                    </div>
                    {truck.purpose && (
                      <div>
                        <span className="block text-xs text-gray-400">Purpose</span>
                        <span className="font-medium">{truck.purpose}</span>
                      </div>
                    )}
                    {truck.bay && (
                      <div>
                        <span className="block text-xs text-gray-400">Bay</span>
                        <span className="font-medium">{truck.bay}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: actions */}
                <div className="flex flex-col items-end gap-3">
                  <div className="flex flex-col gap-2">
                    {!truck.timeIn ? (
                      <button onClick={() => handleSetTimeIn(truck.id)} className="px-3 py-1 rounded border bg-green-50 text-green-700 hover:bg-green-100">Set IN</button>
                    ) : (
                      <button disabled className="px-3 py-1 rounded border bg-green-100 text-green-800 cursor-default">{truck.timeIn}</button>
                    )}

                    {!truck.timeOut ? (
                      <button onClick={() => handleSetTimeOut(truck.id)} className="px-3 py-1 rounded border bg-red-50 text-red-700 hover:bg-red-100">Set OUT</button>
                    ) : (
                      <button disabled className="px-3 py-1 rounded border bg-red-100 text-red-800 cursor-default">{truck.timeOut}</button>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <button onClick={() => handleOpenEdit(truck)} className="px-3 py-1 rounded bg-gray-100 hover:bg-gray-200" title="Edit">✏️</button>
                    <button onClick={() => { if (!window.confirm("Delete this truck?")) return; setTrucks((s) => s.filter((t) => t.id !== truck.id)); }} className="px-3 py-1 rounded bg-red-600 text-white hover:bg-red-700" title="Delete">🗑️</button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

{/* ADD MODAL */}
<Transition appear show={isAddOpen} as={Fragment}>
  <Dialog as="div" className="relative z-30" onClose={() => setIsAddOpen(false)}>
    <Transition.Child as={Fragment} enter="ease-out duration-200" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-150" leaveFrom="opacity-100" leaveTo="opacity-0">
      <div className="fixed inset-0 bg-black bg-opacity-40" />
    </Transition.Child>

    <div className="fixed inset-0 overflow-y-auto">
      <div className="flex min-h-full items-center justify-center p-4">
        <Transition.Child as={Fragment} enter="ease-out duration-200" enterFrom="opacity-0 scale-95" enterTo="opacity-100 scale-100" leave="ease-in duration-150" leaveFrom="opacity-100 scale-100" leaveTo="opacity-0 scale-95">
          <Dialog.Panel className="bg-white w-full max-w-lg rounded-xl shadow-xl p-6">
            <Dialog.Title className="text-xl font-bold text-green-700 mb-3">Add Truck</Dialog.Title>
            <form onSubmit={handleAddTruck} className="grid gap-3">

              {/* Type dropdown */}
              <label className="flex flex-col">
                <span className="text-sm text-gray-600">Type</span>
                <select
                  required
                  value={newTruck.type}
                  onChange={(e) => setNewTruck((s) => ({ ...s, type: e.target.value }))}
className="border rounded px-3 py-2 text-black"
                >
                  <option value="">Select Type</option>
                  <option value="EV">EV</option>
                  <option value="6 Wheeler">6 Wheeler</option>
                  <option value="10 Wheeler">10 Wheeler</option>
                  <option value="Trailer">Trailer</option>
                  <option value="Pickup">Pickup</option>
                </select>
              </label>

              {/* Client Name */}
              <label className="flex flex-col">
                <span className="text-sm text-gray-600">Client Name</span>
                <input
                  required
                  value={newTruck.clientName || ""}
                  onChange={(e) => setNewTruck((s) => ({ ...s, clientName: e.target.value }))}
className="border rounded px-3 py-2 text-black"
                />
              </label>

              {/* Driver */}
              <label className="flex flex-col">
                <span className="text-sm text-gray-600">Driver</span>
                <input
                  required
                  value={newTruck.driver}
                  onChange={(e) => setNewTruck((s) => ({ ...s, driver: e.target.value }))}
className="border rounded px-3 py-2 text-black"
                />
              </label>

              {/* Plate + Bay */}
              <div className="grid grid-cols-2 gap-3">
                <label className="flex flex-col">
                  <span className="text-sm text-gray-600">Plate</span>
                  <input
                    required
                    value={newTruck.plate}
                    onChange={(e) => setNewTruck((s) => ({ ...s, plate: e.target.value }))}
className="border rounded px-3 py-2 text-black"
                  />
                </label>

                <label className="flex flex-col">
                  <span className="text-sm text-gray-600">Bay</span>
                  <select
                    required
                    value={newTruck.bay}
                    onChange={(e) => setNewTruck((s) => ({ ...s, bay: e.target.value }))}
className="border rounded px-3 py-2 text-black"
                  >
                    <option value="">Select Bay</option>
                    {Array.from({ length: 10 }, (_, i) => (
                      <option key={i} value={`${i + 1}A`}>{`${i + 1}A`}</option>
                    ))}
                    {Array.from({ length: 10 }, (_, i) => (
  <option key={i} value={`${i + 1}B`}>{`${i + 1}B`}</option>
))}

                  </select>
                </label>
              </div>

              {/* Purpose */}
              <label className="flex flex-col">
                <span className="text-sm text-gray-600">Purpose</span>
                <input
                  value={newTruck.purpose}
                  onChange={(e) => setNewTruck((s) => ({ ...s, purpose: e.target.value }))}
className="border rounded px-3 py-2 text-black"
                  />
              </label>

              <div className="flex justify-end gap-2 mt-2">
<button
  type="button"
  onClick={() => setIsAddOpen(false)}
  className="px-4 py-2 rounded bg-red-600 text-white hover:bg-red-700 hover:shadow-lg hover:scale-105 transition-all duration-200"
>
  Cancel
</button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700 hover:shadow-lg hover:scale-105 transition-all duration-200"
                  onClick={() => setNewTruck((s) => ({ ...s, date: todayISO, timeIn: fmtNow() }))}
                >
                  Add
                </button>
              </div>
            </form>
          </Dialog.Panel>
        </Transition.Child>
      </div>
    </div>
  </Dialog>
</Transition>


{/* EDIT MODAL */}
<Transition appear show={isEditOpen} as={Fragment}>
  <Dialog as="div" className="relative z-30" onClose={() => setIsEditOpen(false)}>
    <Transition.Child
      as={Fragment}
      enter="ease-out duration-200"
      enterFrom="opacity-0"
      enterTo="opacity-100"
      leave="ease-in duration-150"
      leaveFrom="opacity-100"
      leaveTo="opacity-0"
    >
      <div className="fixed inset-0 bg-black bg-opacity-40" />
    </Transition.Child>

    <div className="fixed inset-0 overflow-y-auto">
      <div className="flex min-h-full items-center justify-center p-4">
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-200"
          enterFrom="opacity-0 scale-95"
          enterTo="opacity-100 scale-100"
          leave="ease-in duration-150"
          leaveFrom="opacity-100 scale-100"
          leaveTo="opacity-0 scale-95"
        >
          <Dialog.Panel className="bg-white w-full max-w-lg rounded-xl shadow-xl p-6">
            <Dialog.Title className="text-xl font-bold text-black mb-3">
              Truck Details
            </Dialog.Title>

            {currentTruck ? (
              <>
                {/* Info Section */}
                <div className="bg-green-50 p-3 rounded mb-4 border border-green-100 text-black">
                  <p><span className="font-semibold">Type:</span> {currentTruck.type}</p>
                  <p><span className="font-semibold">Date:</span> {currentTruck.date}</p>

                  <p><span className="font-semibold">Time In:</span> {currentTruck.timeIn || "—"}</p>
                  <p><span className="font-semibold">Time Out:</span> {currentTruck.timeOut || "—"}</p>

                  <p><span className="font-semibold">Client:</span> {currentTruck.clientName || "—"}</p>

                  <p className="flex items-center gap-2">
                    <span className="font-semibold">Status:</span> {statusBadge(currentTruck)}
                  </p>
                </div>

                <form onSubmit={handleSaveEdit} className="grid gap-3 text-black">

                  <label className="flex flex-col">
                    <span className="text-sm text-black">Driver</span>
                    <input
                      required
                      value={currentTruck.driver || ""}
                      onChange={(e) => setCurrentTruck((c) => ({ ...c, driver: e.target.value }))}
                      className="border rounded px-3 py-2 text-black"
                    />
                  </label>

                  <div className="grid grid-cols-2 gap-3">
                    <label className="flex flex-col">
                      <span className="text-sm text-black">Plate</span>
                      <input
                        required
                        value={currentTruck.plate || ""}
                        onChange={(e) => setCurrentTruck((c) => ({ ...c, plate: e.target.value }))}
                        className="border rounded px-3 py-2 text-black"
                      />
                    </label>

                    {/* BAY — with 1A/1B to 10A/10B */}
                    <label className="flex flex-col">
                      <span className="text-sm text-black">Bay</span>
                      <select
                        value={currentTruck.bay || ""}
                        onChange={(e) =>
                          setCurrentTruck((c) => ({ ...c, bay: e.target.value }))
                        }
                        className="border rounded px-3 py-2 text-black"
                      >
                        <option value="">Select Bay</option>

                        {Array.from({ length: 10 }, (_, i) => (
                          <option key={`A-${i}`} value={`${i + 1}A`}>
                            {`${i + 1}A`}
                          </option>
                        ))}
                        {Array.from({ length: 10 }, (_, i) => (
                          <option key={`B-${i}`} value={`${i + 1}B`}>
                            {`${i + 1}B`}
                          </option>
                        ))}
                      </select>
                    </label>
                  </div>

                  <label className="flex flex-col">
                    <span className="text-sm text-black">Purpose</span>
                    <input
                      value={currentTruck.purpose || ""}
                      onChange={(e) => setCurrentTruck((c) => ({ ...c, purpose: e.target.value }))}
                      className="border rounded px-3 py-2 text-black"
                    />
                  </label>

                  {/* REMOVED TIME IN & TIME OUT INPUTS */}

                  <div className="flex justify-between gap-2 mt-2">
                    <button
                      type="button"
                      onClick={() => setIsEditOpen(false)}
                      className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 text-black"
                    >
                      Cancel
                    </button>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => handleDeleteTruck(currentTruck.id)}
                        className="px-4 py-2 rounded bg-red-600 text-white hover:bg-red-700"
                      >
                        Delete
                      </button>

                      <button
                        type="submit"
                        className="px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                </form>
              </>
            ) : (
              <div>Loading…</div>
            )}
          </Dialog.Panel>
        </Transition.Child>
      </div>
    </div>
  </Dialog>
</Transition>

    </div>
  );
}

/**
 * HistoryDropdown component (small dropdown used in the filter bar)
 */
function HistoryDropdown({ history = [], onApply = () => {}, onClear = () => {}, onRemove = () => {} }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen((s) => !s)} className="px-3 py-2 rounded border bg-white">History ▾</button>
      {open && (
        <div className="absolute right-0 mt-2 w-80 bg-white border rounded shadow-lg z-40">
          <div className="p-3 border-b flex justify-between items-center">
            <strong className="text-sm">Search History</strong>
            <button onClick={() => { onClear(); setOpen(false); }} className="text-xs text-red-600">Clear</button>
          </div>
          <div className="max-h-56 overflow-auto">
            {history.length === 0 ? (
              <div className="p-3 text-sm text-gray-500">No saved searches</div>
            ) : (
              history.map((h) => (
                <div key={h.id} className="p-3 border-b flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="text-sm font-medium">{h.name}</div>
                    <div className="text-xs text-gray-500">{new Date(h.createdAt).toLocaleString()}</div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <button onClick={() => { onApply(h); setOpen(false); }} className="text-xs px-2 py-1 rounded bg-green-600 text-white">Apply</button>
                    <button onClick={() => onRemove(h.id)} className="text-xs px-2 py-1 rounded bg-gray-200">Remove</button>
                  </div>
                </div>
              ))
            )}
          </div>
          <div className="p-3 text-center text-xs text-gray-500">Saved searches persist in your browser.</div>
        </div>
      )}
    </div>
  );
}
